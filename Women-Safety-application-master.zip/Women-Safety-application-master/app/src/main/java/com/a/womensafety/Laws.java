package com.a.womensafety;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Laws extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laws);

        getSupportActionBar().setTitle("Laws Related to Women Safety");
    }
}
